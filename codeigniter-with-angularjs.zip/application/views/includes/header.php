<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'header-content.php'; ?>
</head>
<body class="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
<input type="hidden" id="base_path" value="<?php echo base_url(); ?>"/>
<?php include 'header-menu.php'; ?>
<div class="app-body">
	<?php include 'sidebar-menu.php'; ?>