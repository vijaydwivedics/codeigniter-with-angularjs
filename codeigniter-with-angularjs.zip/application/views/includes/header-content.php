<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<meta name="description" content="CI Admin - Open Source Bootstrap Admin Template">
<meta name="author" content="Łukasz Holeczek">
<meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
<link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon.ico">
<title>CI Admin : Dashboard</title>
<!-- Icons -->
<link href="<?php echo base_url(); ?>assets/icons/coreui/css/coreui-icons.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/icons/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/icons/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/icons/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
<!-- Main styles for this application -->
<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/icons/pace-progress/css/pace.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/custom.style.css" rel="stylesheet">